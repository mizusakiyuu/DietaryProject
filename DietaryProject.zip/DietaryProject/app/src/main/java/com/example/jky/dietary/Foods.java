package com.example.jky.dietary;

public class Foods {

    String userId;
    String userDayChoose;
    String userMealChoose;
    String foodSpinner1;
    String foodSpinner2;
    String foodspinner3;

    public Foods(){

    }

    public Foods(String userId, String userDayChoose, String userMealChoose, String foodSpinner1, String foodSpinner2, String foodspinner3) {
        this.userId = userId;
        this.userDayChoose = userDayChoose;
        this.userMealChoose = userMealChoose;
        this.foodSpinner1 = foodSpinner1;
        this.foodSpinner2 = foodSpinner2;
        this.foodspinner3 = foodspinner3;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserDayChoose() {
        return userDayChoose;
    }

    public void setUserDayChoose(String userDayChoose) {
        this.userDayChoose = userDayChoose;
    }

    public String getUserMealChoose() {
        return userMealChoose;
    }

    public void setUserMealChoose(String userMealChoose) {
        this.userMealChoose = userMealChoose;
    }

    public String getFoodSpinner1() {
        return foodSpinner1;
    }

    public void setFoodSpinner1(String foodSpinner1) {
        this.foodSpinner1 = foodSpinner1;
    }

    public String getFoodSpinner2() {
        return foodSpinner2;
    }

    public void setFoodSpinner2(String foodSpinner2) {
        this.foodSpinner2 = foodSpinner2;
    }

    public String getFoodspinner3() {
        return foodspinner3;
    }

    public void setFoodspinner3(String foodspinner3) {
        this.foodspinner3 = foodspinner3;
    }
}
