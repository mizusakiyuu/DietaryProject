package com.example.jky.dietary;


import android.app.Activity;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class FoodList extends ArrayAdapter<Foods> {

    private Activity context;
    private List<Foods> foodList;

    public FoodList(Activity context, List<Foods> foodList) {
        super(context, R.layout.list_layout, foodList);
        this.context = context;
        this.foodList = foodList;

    }

    @NonNull
    @Override
    public View getView(int position, View ConvertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list_layout, null, true);

        TextView textViewDay = (TextView) listViewItem.findViewById(R.id.textviewDay);
        TextView textViewMeal = (TextView) listViewItem.findViewById(R.id.textviewMeal);
        TextView food1 = (TextView) listViewItem.findViewById(R.id.food1);
        TextView food2 = (TextView) listViewItem.findViewById(R.id.food2);
        TextView food3 = (TextView) listViewItem.findViewById(R.id.food3);

        Foods foods = foodList.get(position);
        textViewDay.setText(foods.getUserDayChoose());
        textViewMeal.setText(foods.getUserMealChoose());
        food1.setText(foods.getFoodSpinner1());
        food2.setText(foods.getFoodSpinner2());
        food3.setText(foods.getFoodspinner3());
        return listViewItem;
    }
}