package com.example.jky.dietary;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DayOneBreakfastActivity extends AppCompatActivity implements View.OnClickListener {

    private Button backButton, nextButton, updateButton;
    private Spinner dayEditText, mealTimeEditText;
    private Spinner spinner1, spinner2, spinner3;
    private DatabaseReference databaseFood;
    private FirebaseAuth mAuth;
    private ListView listViewFoods;
    private List<Foods> foodsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_one_breakfast);

        mAuth = FirebaseAuth.getInstance();
        databaseFood = FirebaseDatabase.getInstance().getReference("Foods");

        backButton = (Button) findViewById(R.id.backButton);
        updateButton = (Button) findViewById(R.id.updateButton);
        nextButton = (Button) findViewById(R.id.updateButton);
        dayEditText = (Spinner)findViewById(R.id.dayEditText);

        mealTimeEditText = (Spinner)findViewById(R.id.mealTimeEditText);
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        spinner3 = (Spinner) findViewById(R.id.spinner3);
        listViewFoods = (ListView)findViewById(R.id.listViewFoods);
        foodsList = new ArrayList<>();
        backButton.setOnClickListener(this);
        updateButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);

    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseFood.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                foodsList.clear();
                for(DataSnapshot foodSnapshot : dataSnapshot.getChildren() ){
                    Foods foods = foodSnapshot.getValue(Foods.class);
                    foodsList.add(foods);
                }

                FoodList adapter = new FoodList(DayOneBreakfastActivity.this,foodsList);
                listViewFoods.setAdapter(adapter);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onClick(View v) {

        if (v == updateButton) {
            updateFood();
        }
        if (v == backButton) {
            backToLogin();
        }

    }

    private void updateFood() {
        String spinner1st = spinner1.getSelectedItem().toString();
        String spinner2nd = spinner2.getSelectedItem().toString();
        String spinner3rd = spinner3.getSelectedItem().toString();
        String day = dayEditText.getSelectedItem().toString();
        String meal = mealTimeEditText.getSelectedItem().toString();

        if(TextUtils.isEmpty(day)){
            Toast.makeText(DayOneBreakfastActivity.this, "Please enter the day", Toast.LENGTH_SHORT).show();
            return;
        }  if(TextUtils.isEmpty(meal)){
            Toast.makeText(DayOneBreakfastActivity.this, "Please enter the meal", Toast.LENGTH_SHORT).show();
            return;
        } else{

            String id = databaseFood.push().getKey();
            Foods foods = new Foods(id,day,meal,spinner1st,spinner2nd,spinner3rd);
            databaseFood.child(id).setValue(foods);
            Toast.makeText(DayOneBreakfastActivity.this,"Food Diet Added", Toast.LENGTH_SHORT).show();
        }


    }

    private void backToLogin() {
        startActivity(new Intent(DayOneBreakfastActivity.this, MainActivity.class));
    }

}
