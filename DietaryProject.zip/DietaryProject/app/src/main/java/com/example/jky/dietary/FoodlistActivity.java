package com.example.jky.dietary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import com.example.jky.dietary.DayOneBreakfastActivity;

public class FoodlistActivity extends AppCompatActivity {

    private ListView listViewFoods;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodlist);
        listViewFoods = (ListView)findViewById(R.id.listViewFoods);


    }


}
